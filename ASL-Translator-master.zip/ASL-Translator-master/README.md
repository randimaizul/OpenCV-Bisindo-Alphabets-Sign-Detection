# ASL-Translator
American Sign Language Translator using OpenCV and Machine Learning.

Procedure to run :-
Just run ASL.py
Description:-
Based on 17 classes training data SVM classifier gets trained with HOG based approach and after predicting the correct result we can write the words on screen to form a sentence.
This app is good for thos who don't understand ASL and can just hold the phone camera infront of an ASL user and the app can decode it in form of a sentence.

##Very basic approach for detecting hands , i.e.,Skin color segmentation using YCbCr colorspace . Provided a trackbar to adjust to a particular skin color.


Features:-
1.Detects Alphabets upto 'O'.
2.Thumbs up is 'P' here which means space.
3.Gesture five is 'Q' which means to remove the last wrong word.



youtube video link - https://www.youtube.com/watch?v=RuOMUK76-0Q&feature=youtu.be
